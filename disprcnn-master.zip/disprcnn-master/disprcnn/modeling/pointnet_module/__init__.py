from .point_rcnn.lib.net.point_rcnn import PointRCNN

