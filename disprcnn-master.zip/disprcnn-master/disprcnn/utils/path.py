import os
from pathlib2 import Path

PROJECT_ROOT = str(Path(os.path.abspath(__file__)).parent.parent.parent)
