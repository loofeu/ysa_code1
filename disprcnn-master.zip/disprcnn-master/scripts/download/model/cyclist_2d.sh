mkdir -p models/kitti/cyclist/mask
gdown --id 1YaRloxSclO0yHvt2rOhvBrKivo8siyi2 -O models/kitti/cyclist/
unzip models/kitti/cyclist/mask.zip -d models/kitti/cyclist
rm models/kitti/cyclist/mask.zip