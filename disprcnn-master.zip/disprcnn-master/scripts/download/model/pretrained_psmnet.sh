mkdir -p models/PSMNet
gdown --id 1pHWjmhKMG4ffCrpcsp_MTXMJXhgl3kF9 -O models/PSMNet/