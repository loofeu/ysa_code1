mkdir -p models/kitti/pedestrian/mask
gdown --id 1PxqmzDKznwehwIXEOsF7TdZPc641faiT -O models/kitti/pedestrian/
unzip models/kitti/pedestrian/mask.zip -d models/kitti/pedestrian
rm models/kitti/pedestrian/mask.zip