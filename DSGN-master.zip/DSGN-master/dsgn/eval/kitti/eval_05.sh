echo "evalutating $1 ..."

./evaluate_object_3d_offline_05 ../../../data/kitti/training/label_2/ $1
