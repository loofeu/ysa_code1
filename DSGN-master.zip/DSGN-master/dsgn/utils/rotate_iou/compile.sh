g++ -o calculate_iou.so -shared -fPIC calculate_iou.cpp
